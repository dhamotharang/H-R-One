Insert into ReminderType (ReminderTypeCode,ReminderTypeDesc)
Values ('DOB18', 'Age of 18 Birthday Reminder')

Insert into ReminderType (ReminderTypeCode,ReminderTypeDesc)
Values ('DOB', 'Age of 18 Birthday Reminder')

Insert into ReminderType (ReminderTypeCode,ReminderTypeDesc)
Values ('DOB65', 'Age of 65 Birthday Reminder')
