	UPDATE PayrollGroup
	Set PayGroupUseCNDForDailyHourlyPayment=1
	WHERE PayGroupUseCNDForDailyHourlyPayment is NULL
