INSERT INTO BankList
           (BankCode
           ,BankName)
     VALUES
           ('003','STANDARD CHARTERED BANK (HONG KONG) LIMITED')
INSERT INTO BankList
           (BankCode
           ,BankName)
     VALUES
           ('004','THE HONGKONG AND SHANGHAI BANKING CORPORATION LIMITED')
INSERT INTO BankList
           (BankCode
           ,BankName)
     VALUES
           ('005','CALYON')
INSERT INTO BankList
           (BankCode
           ,BankName)
     VALUES
           ('006','CITIBANK, N.A.')
INSERT INTO BankList
           (BankCode
           ,BankName)
     VALUES
           ('007','JPMORGAN CHASE BANK, N.A.')
INSERT INTO BankList
           (BankCode
           ,BankName)
     VALUES
           ('008','ABN AMRO BANK N.V.')
INSERT INTO BankList
           (BankCode
           ,BankName)
     VALUES
           ('009','CHINA CONSTRUCTION BANK (ASIA) CORPORATION LIMITED')
INSERT INTO BankList
           (BankCode
           ,BankName)
     VALUES
           ('012','BANK OF CHINA (HONG KONG) LIMITED')
INSERT INTO BankList
           (BankCode
           ,BankName)
     VALUES
           ('015','THE BANK OF EAST ASIA, LIMITED')
INSERT INTO BankList
           (BankCode
           ,BankName)
     VALUES
           ('016','DBS BANK (HONG KONG) LIMITED')
INSERT INTO BankList
           (BankCode
           ,BankName)
     VALUES
           ('018','CITIC KA WAH BANK LIMITED')
INSERT INTO BankList
           (BankCode
           ,BankName)
     VALUES
           ('020','WING LUNG BANK LIMITED')
INSERT INTO BankList
           (BankCode
           ,BankName)
     VALUES
           ('021','MEVAS BANK LIMITED')
INSERT INTO BankList
           (BankCode
           ,BankName)
     VALUES
           ('022','OVERSEA-CHINESE BANKING CORPORATION LTD.')
INSERT INTO BankList
           (BankCode
           ,BankName)
     VALUES
           ('024','HANG SENG BANK LTD.')
INSERT INTO BankList
           (BankCode
           ,BankName)
     VALUES
           ('025','SHANGHAI COMMERCIAL BANK LTD.')
INSERT INTO BankList
           (BankCode
           ,BankName)
     VALUES
           ('027','BANK OF COMMUNICATIONS CO., LTD')
INSERT INTO BankList
           (BankCode
           ,BankName)
     VALUES
           ('028','PUBLIC BANK (HONG KONG) LIMITED')
INSERT INTO BankList
           (BankCode
           ,BankName)
     VALUES
           ('035','WING HANG BANK LTD.')
INSERT INTO BankList
           (BankCode
           ,BankName)
     VALUES
           ('038','TAI YAU BANK LTD.')
INSERT INTO BankList
           (BankCode
           ,BankName)
     VALUES
           ('039','CHIYU BANKING CORPORATION LTD.')
INSERT INTO BankList
           (BankCode
           ,BankName)
     VALUES
           ('040','DAH SING BANK, LTD.')
INSERT INTO BankList
           (BankCode
           ,BankName)
     VALUES
           ('041','CHONG HING BANK LIMITED')
INSERT INTO BankList
           (BankCode
           ,BankName)
     VALUES
           ('043','NANYANG COMMERCIAL BANK, LTD.')
INSERT INTO BankList
           (BankCode
           ,BankName)
     VALUES
           ('045','UCO BANK')
INSERT INTO BankList
           (BankCode
           ,BankName)
     VALUES
           ('046','KOREA EXCHANGE BANK')
INSERT INTO BankList
           (BankCode
           ,BankName)
     VALUES
           ('047','THE BANK OF TOKYO-MITSUBISHI UFJ, LTD.')
INSERT INTO BankList
           (BankCode
           ,BankName)
     VALUES
           ('049','BANGKOK BANK PUBLIC COMPANY LIMITED')
INSERT INTO BankList
           (BankCode
           ,BankName)
     VALUES
           ('050','INDIAN OVERSEAS BANK')
INSERT INTO BankList
           (BankCode
           ,BankName)
     VALUES
           ('054','DEUTSCHE BANK AG')
INSERT INTO BankList
           (BankCode
           ,BankName)
     VALUES
           ('055','BANK OF AMERICA, N.A.')
INSERT INTO BankList
           (BankCode
           ,BankName)
     VALUES
           ('056','BNP PARIBAS')
INSERT INTO BankList
           (BankCode
           ,BankName)
     VALUES
           ('058','BANK OF INDIA')
INSERT INTO BankList
           (BankCode
           ,BankName)
     VALUES
           ('060','NATIONAL BANK OF PAKISTAN')
INSERT INTO BankList
           (BankCode
           ,BankName)
     VALUES
           ('061','TAI SANG BANK LTD.')
INSERT INTO BankList
           (BankCode
           ,BankName)
     VALUES
           ('063','MALAYAN BANKING BERHAD (MAYBANK)')
INSERT INTO BankList
           (BankCode
           ,BankName)
     VALUES
           ('065','SUMITOMO MITSUI BANKING CORPORATION')
INSERT INTO BankList
           (BankCode
           ,BankName)
     VALUES
           ('066','PT. BANK NEGARA INDONESIA (PERSERO) TBK.')
INSERT INTO BankList
           (BankCode
           ,BankName)
     VALUES
           ('067','BANCO DE ORO UNIBANK, INC.')
INSERT INTO BankList
           (BankCode
           ,BankName)
     VALUES
           ('071','UNITED OVERSEAS BANK LTD.')
INSERT INTO BankList
           (BankCode
           ,BankName)
     VALUES
           ('072','INDUSTRIAL AND COMMERCIAL BANK OF CHINA (ASIA) LIMITED')
INSERT INTO BankList
           (BankCode
           ,BankName)
     VALUES
           ('074','BARCLAYS BANK PLC.')
INSERT INTO BankList
           (BankCode
           ,BankName)
     VALUES
           ('076','THE BANK OF NOVA SCOTIA')
INSERT INTO BankList
           (BankCode
           ,BankName)
     VALUES
           ('080','ROYAL BANK OF CANADA')
INSERT INTO BankList
           (BankCode
           ,BankName)
     VALUES
           ('081','SOCIETE GENERALE')
INSERT INTO BankList
           (BankCode
           ,BankName)
     VALUES
           ('082','STATE BANK OF INDIA')
INSERT INTO BankList
           (BankCode
           ,BankName)
     VALUES
           ('085','THE TORONTO-DOMINION BANK')
INSERT INTO BankList
           (BankCode
           ,BankName)
     VALUES
           ('086','BANK OF MONTREAL')
INSERT INTO BankList
           (BankCode
           ,BankName)
     VALUES
           ('091','THE ROYAL BANK OF SCOTLAND PLC')
INSERT INTO BankList
           (BankCode
           ,BankName)
     VALUES
           ('092','CANADIAN IMPERIAL BANK OF COMMERCE')
INSERT INTO BankList
           (BankCode
           ,BankName)
     VALUES
           ('093','BANK OF SCOTLAND')
INSERT INTO BankList
           (BankCode
           ,BankName)
     VALUES
           ('097','COMMERZBANK AG')
INSERT INTO BankList
           (BankCode
           ,BankName)
     VALUES
           ('103','UBS AG, HONG KONG')
INSERT INTO BankList
           (BankCode
           ,BankName)
     VALUES
           ('106','HSBC BANK USA, N.A.')
INSERT INTO BankList
           (BankCode
           ,BankName)
     VALUES
           ('109','MIZUHO CORPORATE BANK, LTD., HONG KONG BRANCH')
INSERT INTO BankList
           (BankCode
           ,BankName)
     VALUES
           ('112','HANA BANK')
INSERT INTO BankList
           (BankCode
           ,BankName)
     VALUES
           ('113','DZ BANK AG DEUTSCHE ZENTRAL - GENOSSENSCHAFTSBANK')
INSERT INTO BankList
           (BankCode
           ,BankName)
     VALUES
           ('118','WOORI BANK')
INSERT INTO BankList
           (BankCode
           ,BankName)
     VALUES
           ('119','PHILIPPINE NATIONAL BANK')
INSERT INTO BankList
           (BankCode
           ,BankName)
     VALUES
           ('128','FUBON BANK (HONG KONG) LIMITED')
INSERT INTO BankList
           (BankCode
           ,BankName)
     VALUES
           ('133','HSH NORDBANK AG')
INSERT INTO BankList
           (BankCode
           ,BankName)
     VALUES
           ('138','MITSUBISHI UFJ TRUST AND BANKING CORPORATION')
INSERT INTO BankList
           (BankCode
           ,BankName)
     VALUES
           ('139','THE BANK OF NEW YORK MELLON')
INSERT INTO BankList
           (BankCode
           ,BankName)
     VALUES
           ('145','ING BANK N.V.')
INSERT INTO BankList
           (BankCode
           ,BankName)
     VALUES
           ('147','BANCO BILBAO VIZCAYA ARGENTARIA, S.A.')
INSERT INTO BankList
           (BankCode
           ,BankName)
     VALUES
           ('150','NATIONAL AUSTRALIA BANK LIMITED')
INSERT INTO BankList
           (BankCode
           ,BankName)
     VALUES
           ('151','WESTPAC BANKING CORPORATION')
INSERT INTO BankList
           (BankCode
           ,BankName)
     VALUES
           ('152','AUSTRALIA AND NEW ZEALAND BANKING GROUP LIMITED')
INSERT INTO BankList
           (BankCode
           ,BankName)
     VALUES
           ('153','COMMONWEALTH BANK OF AUSTRALIA')
INSERT INTO BankList
           (BankCode
           ,BankName)
     VALUES
           ('161','INTESA SANPAOLO S.P.A.')
INSERT INTO BankList
           (BankCode
           ,BankName)
     VALUES
           ('164','BAYERISCHE HYPO-UND VEREINSBANK AG, HONG KONG BRANCH')
INSERT INTO BankList
           (BankCode
           ,BankName)
     VALUES
           ('165','SVENSKA HANDELSBANKEN AB (PUBL)')
INSERT INTO BankList
           (BankCode
           ,BankName)
     VALUES
           ('170','THE CHIBA BANK, LTD.')
INSERT INTO BankList
           (BankCode
           ,BankName)
     VALUES
           ('176','UNICREDIT, SOCIETA'' PER AZIONI')
INSERT INTO BankList
           (BankCode
           ,BankName)
     VALUES
           ('178','KBC BANK N.V., HONG KONG BRANCH')
INSERT INTO BankList
           (BankCode
           ,BankName)
     VALUES
           ('180','WELLS FARGO BANK, N.A., HONG KONG BRANCH')
INSERT INTO BankList
           (BankCode
           ,BankName)
     VALUES
           ('183','COOPERATIEVE CENTRALE RAIFFEISEN - BOERENLEENBANK B.A.')
INSERT INTO BankList
           (BankCode
           ,BankName)
     VALUES
           ('185','DBS BANK LTD. HONG KONG BRANCH')
INSERT INTO BankList
           (BankCode
           ,BankName)
     VALUES
           ('186','THE SHIZUOKA BANK LTD.')
INSERT INTO BankList
           (BankCode
           ,BankName)
     VALUES
           ('188','THE HACHIJUNI BANK, LTD.')
INSERT INTO BankList
           (BankCode
           ,BankName)
     VALUES
           ('196','STANDARD BANK ASIA LIMITED')
INSERT INTO BankList
           (BankCode
           ,BankName)
     VALUES
           ('198','HUA NAN COMMERCIAL BANK, LTD')
INSERT INTO BankList
           (BankCode
           ,BankName)
     VALUES
           ('199','THE SHIGA BANK, LTD')
INSERT INTO BankList
           (BankCode
           ,BankName)
     VALUES
           ('201','BANK OF TAIWAN')
INSERT INTO BankList
           (BankCode
           ,BankName)
     VALUES
           ('202','THE CHUGOKU BANK LIMITED')
INSERT INTO BankList
           (BankCode
           ,BankName)
     VALUES
           ('203','FIRST COMMERCIAL BANK')
INSERT INTO BankList
           (BankCode
           ,BankName)
     VALUES
           ('205','RBS COUTTS BANK LTD.')
INSERT INTO BankList
           (BankCode
           ,BankName)
     VALUES
           ('206','CHANG HWA COMMERCIAL BANK, LTD.')
INSERT INTO BankList
           (BankCode
           ,BankName)
     VALUES
           ('208','BAYERISCHE LANDESBANK')
INSERT INTO BankList
           (BankCode
           ,BankName)
     VALUES
           ('210','NATIXIS')
INSERT INTO BankList
           (BankCode
           ,BankName)
     VALUES
           ('214','INDUSTRIAL AND COMMERCIAL BANK OF CHINA LIMITED')
INSERT INTO BankList
           (BankCode
           ,BankName)
     VALUES
           ('218','WESTLB AG')
INSERT INTO BankList
           (BankCode
           ,BankName)
     VALUES
           ('220','STATE STREET BANK AND TRUST COMPANY')
INSERT INTO BankList
           (BankCode
           ,BankName)
     VALUES
           ('221','CHINA CONSTRUCTION BANK CORPORATION')
INSERT INTO BankList
           (BankCode
           ,BankName)
     VALUES
           ('222','AGRICULTURAL BANK OF CHINA')
INSERT INTO BankList
           (BankCode
           ,BankName)
     VALUES
           ('224','THE IYO BANK, LTD., HONG KONG BRANCH')
INSERT INTO BankList
           (BankCode
           ,BankName)
     VALUES
           ('225','FORTIS BANK, HONG KONG BRANCH')
INSERT INTO BankList
           (BankCode
           ,BankName)
     VALUES
           ('226','SHINKIN CENTRAL BANK')
INSERT INTO BankList
           (BankCode
           ,BankName)
     VALUES
           ('227','ERSTE GROUP BANK AG')
INSERT INTO BankList
           (BankCode
           ,BankName)
     VALUES
           ('229','CHINATRUST COMMERCIAL BANK, LTD.')
INSERT INTO BankList
           (BankCode
           ,BankName)
     VALUES
           ('230','TAIWAN BUSINESS BANK, HONG KONG BRANCH')
INSERT INTO BankList
           (BankCode
           ,BankName)
     VALUES
           ('233','CREDIT SUISSE')
INSERT INTO BankList
           (BankCode
           ,BankName)
     VALUES
           ('234','BANCA MONTE DEI PASCHI DI SIENA S.P.A. HONG KONG BRANCH')
INSERT INTO BankList
           (BankCode
           ,BankName)
     VALUES
           ('235','HSBC PRIVATE BANK (SUISSE) SA')
INSERT INTO BankList
           (BankCode
           ,BankName)
     VALUES
           ('236','CATHAY UNITED BANK COMPANY, LIMITED')
INSERT INTO BankList
           (BankCode
           ,BankName)
     VALUES
           ('237','EFG BANK')
INSERT INTO BankList
           (BankCode
           ,BankName)
     VALUES
           ('238','CHINA MERCHANTS BANK CO., LTD.')
INSERT INTO BankList
           (BankCode
           ,BankName)
     VALUES
           ('239','TAIPEI FUBON COMMERCIAL BANK CO., LTD.')
INSERT INTO BankList
           (BankCode
           ,BankName)
     VALUES
           ('240','BNP PARIBAS WEALTH MANAGEMENT')
INSERT INTO BankList
           (BankCode
           ,BankName)
     VALUES
           ('241','BANK SINOPAC')
INSERT INTO BankList
           (BankCode
           ,BankName)
     VALUES
           ('242','MEGA INTERNATIONAL COMMERCIAL BANK CO., LTD.')
INSERT INTO BankList
           (BankCode
           ,BankName)
     VALUES
           ('243','E. SUN COMMERCIAL BANK, LTD.')
INSERT INTO BankList
           (BankCode
           ,BankName)
     VALUES
           ('245','TAISHIN INTERNATIONAL BANK CO., LTD.')
INSERT INTO BankList
           (BankCode
           ,BankName)
     VALUES
           ('246','UNITED COMMERCIAL BANK')
INSERT INTO BankList
           (BankCode
           ,BankName)
     VALUES
           ('247','PUBLIC BANK BERHAD')
INSERT INTO BankList
           (BankCode
           ,BankName)
     VALUES
           ('248','HONG LEONG BANK BERHAD')
INSERT INTO BankList
           (BankCode
           ,BankName)
     VALUES
           ('249','STANDARD CHARTERED BANK HONG KONG BRANCH')
INSERT INTO BankList
           (BankCode
           ,BankName)
     VALUES
           ('250','CITIBANK (HONG KONG) LIMITED')
INSERT INTO BankList
           (BankCode
           ,BankName)
     VALUES
           ('251','ICICI BANK LIMITED')
INSERT INTO BankList
           (BankCode
           ,BankName)
     VALUES
           ('253','AIG PRIVATE BANK LTD.')
INSERT INTO BankList
           (BankCode
           ,BankName)
     VALUES
           ('254','MELLI BANK PLC')
INSERT INTO BankList
           (BankCode
           ,BankName)
     VALUES
           ('255','SOCIETE GENERALE BANK & TRUST')
INSERT INTO BankList
           (BankCode
           ,BankName)
     VALUES
           ('256','ALLAHABAD BANK')
INSERT INTO BankList
           (BankCode
           ,BankName)
     VALUES
           ('257','NEWEDGE GROUP')
INSERT INTO BankList
           (BankCode
           ,BankName)
     VALUES
           ('258','EAST WEST BANK')
INSERT INTO BankList
           (BankCode
           ,BankName)
     VALUES
           ('259','BANK OF BARODA')
INSERT INTO BankList
           (BankCode
           ,BankName)
     VALUES
           ('260','FAR EASTERN INTERNATIONAL BANK')
INSERT INTO BankList
           (BankCode
           ,BankName)
     VALUES
           ('261','AXIS BANK LIMITED')
INSERT INTO BankList
           (BankCode
           ,BankName)
     VALUES
           ('262','CANARA BANK')
INSERT INTO BankList
           (BankCode
           ,BankName)
     VALUES
           ('263','CATHAY BANK')
INSERT INTO BankList
           (BankCode
           ,BankName)
     VALUES
           ('264','LAND BANK OR TAIWAN CO., LTD')
INSERT INTO BankList
           (BankCode
           ,BankName)
     VALUES
           ('265','TAIWAN COOPERATIVE BANK, LTD.')
INSERT INTO BankList
           (BankCode
           ,BankName)
     VALUES
           ('266','PUNJAB NATIONAL BANK')
INSERT INTO BankList
           (BankCode
           ,BankName)
     VALUES
           ('267','BANCO SANTANDER S.A.')
INSERT INTO BankList
           (BankCode
           ,BankName)
     VALUES
           ('268','UNION BANK OF INDIA')
INSERT INTO BankList
           (BankCode
           ,BankName)
     VALUES
           ('269','THE SHANGHAI COMMERCIAL & SAVINGS BANK, LTD.')
INSERT INTO BankList
           (BankCode
           ,BankName)
     VALUES
           ('270','DEPFA BANK PLC')
INSERT INTO BankList
           (BankCode
           ,BankName)
     VALUES
           ('271','INDUSTRIAL BANK OF KOREA')
INSERT INTO BankList
           (BankCode
           ,BankName)
     VALUES
           ('272','ING ASIA PRIVATE BANK LTD.')
INSERT INTO BankList
           (BankCode
           ,BankName)
     VALUES
           ('273','SHINHAN BANK')
INSERT INTO BankList
           (BankCode
           ,BankName)
     VALUES
           ('868','CLS BANK INTERNATIONAL')
