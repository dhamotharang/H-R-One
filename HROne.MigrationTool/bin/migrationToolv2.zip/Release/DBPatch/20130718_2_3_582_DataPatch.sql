UPDATE LeaveType
SET LeaveTypeIsDisabled=0
WHERE LeaveTypeIsDisabled IS NULL
