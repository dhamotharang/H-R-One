Update PayrollPeriod
set PayPeriodIsAutoCreate = 1
where PayPeriodIsAutoCreate is null