Insert into DocumentType (DocumentTypeCode, DocumentTypeDesc,DocumentTypeIsSystem)
Values ('PHOTO', 'Photo',1)